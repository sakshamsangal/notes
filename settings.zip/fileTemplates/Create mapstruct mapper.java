/*
 * Copyright 2023 Thomson Reuters/ONESOURCE. All rights reserved.
 */
package ${PACKAGE_NAME};

import org.mapstruct.BeanMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;


@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ${NAME}Mapper {

    ${NAME}Mapper INSTANCE = Mappers.getMapper(${NAME}Mapper.class);

    @BeanMapping(ignoreByDefault = true)
    Object toObject(${NAME} obj);
}