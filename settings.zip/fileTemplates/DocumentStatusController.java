/*
 * Copyright 2023 Thomson Reuters/ONESOURCE. All rights reserved.
 */
package ${PACKAGE_NAME};


import com.thomsonreuters.einv.api.model.process_document.request.ApplicationResponse;
import com.thomsonreuters.einv.api.service.DocumentStatusService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@Slf4j
@RequiredArgsConstructor
@RequestMapping("/v1/documents")
@RestController
public class ${NAME} implements DocumentStatusApi {

    private final DocumentStatusService documentStatusService;


    /**
     * It will take eDocumentId as path variable, search in transaction table
     * for the status and return the status as response.
     * @param id  eDocumentId
     * @return status code
     */
    @GetMapping("/{id}/status")
    @Override
    public ResponseEntity<ApplicationResponse> getDocumentStatusCode(String id) {
        ApplicationResponse applicationResponse = documentStatusService.getStatus(id);
        return new ResponseEntity<>(applicationResponse, HttpStatus.OK);
    }

}
