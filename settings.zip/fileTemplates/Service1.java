/*
 * Copyright 2023 Thomson Reuters/ONESOURCE. All rights reserved.
 */

package ${PACKAGE_NAME};

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ${NAME}Service {


}
