/*
 * Copyright 2023 Thomson Reuters/ONESOURCE. All rights reserved.
 */
package ${PACKAGE_NAME};

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonMappingException.Reference;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.thomsonreuters.einv.api.db_service.ProcessDocumentArDbService;
import com.thomsonreuters.einv.api.mapper.app_res.ApplicationResponseMapper;
import com.thomsonreuters.einv.api.model.error.ApiError;
import com.thomsonreuters.einv.api.model.process_document.request.ApplicationResponse;
import com.thomsonreuters.einv.api.model.process_document.request.DocumentResponse;
import com.thomsonreuters.einv.api.util.Constants;
import com.thomsonreuters.einv.api.util.DBStatusCodeConstants;
import com.thomsonreuters.einv.api.util.ErrorMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.factory.Mappers;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Objects;

import static org.springframework.core.Ordered.HIGHEST_PRECEDENCE;

@Slf4j
@RestControllerAdvice
@Order(HIGHEST_PRECEDENCE)
public final class ${NAME} extends ResponseEntityExceptionHandler {

    @Autowired
    private ProcessDocumentArDbService processDocumentArDbService;

    @Autowired
    private MessageSource messageSource;

    private MessageSourceAccessor messageSourceAccessor;


    /**
     * Handle method argument type mismatch Exception.
     *
     * @param ex      the exception.
     * @param request the current request.
     * @return a {@code ResponseEntity} instance.
     */
    @ExceptionHandler({MethodArgumentTypeMismatchException.class})
    public ResponseEntity<Object> handleMethodArgumentTypeMismatch(final MethodArgumentTypeMismatchException ex,
                                                                   final WebRequest request) {
        log.error("OSEI - Method argument type mismatch exception -> {}", ex.getMessage(), ex);

        final String error = ex.getName() + " should be of type " + Objects.requireNonNull(ex.getRequiredType()).getName();
        final ApiError apiError = new ApiError();

        apiError.setCode(HttpStatus.BAD_REQUEST.getReasonPhrase());
        apiError.addMessagesItem(error);

        return new ResponseEntity<>(apiError, new HttpHeaders(), HttpStatus.BAD_REQUEST);
    }

    /**
     * Handle http request method not supported exception.
     *
     * @param ex      the exception.
     * @param headers the headers to be written to the response.
     * @param status  the selected response status.
     * @param request the current request.
     * @return a {@code ResponseEntity} instance.
     */
    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(final HttpRequestMethodNotSupportedException ex,
                                                                         final HttpHeaders headers,
                                                                         final HttpStatusCode status,
                                                                         final WebRequest request) {
        log.error("OSEI - Http request method not supported exception -> {}", ex.getMessage(), ex);

        final StringBuilder builder = new StringBuilder();

        builder.append(ex.getMethod());
        builder.append(" method is not supported for this request. Supported methods are ");

        Objects.requireNonNull(ex.getSupportedHttpMethods()).forEach(t -> builder.append(t).append(" "));

        final ApiError apiError = new ApiError();
        apiError.setCode(HttpStatus.BAD_REQUEST.getReasonPhrase());
        apiError.addMessagesItem(builder.toString());

        return new ResponseEntity<>(apiError, new HttpHeaders(), status);
    }

    /**
     * Handle http media type not supported exception.
     *
     * @param ex      the exception.
     * @param headers the headers to be written to the response.
     * @param status  the selected response status.
     * @param request the current request.
     * @return a {@code ResponseEntity} instance.
     */
    @Override
    protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(final HttpMediaTypeNotSupportedException ex,
                                                                     final HttpHeaders headers,
                                                                     final HttpStatusCode status,
                                                                     final WebRequest request) {

        log.error("OSEI - Http media type not supported exception -> {}", ex.getMessage(), ex);
        final StringBuilder builder = new StringBuilder();
        builder.append(ex.getContentType());
        builder.append(" media type is not supported. Supported media types are ");
        ex.getSupportedMediaTypes().forEach(t -> builder.append(t).append(", "));

        final ApiError apiError = new ApiError();
        apiError.setCode(HttpStatus.BAD_REQUEST.getReasonPhrase());

        apiError.addMessagesItem(builder.substring(0, builder.length() - 2));

        return new ResponseEntity<>(apiError, new HttpHeaders(), status);
    }


    /**
     * Handle method argument not valid.
     *
     * @param ex      the exception.
     * @param headers the headers to be written to the response.
     * @param status  the selected response status.
     * @param request the current request.
     * @return a {@code ResponseEntity} instance.
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(final MethodArgumentNotValidException ex,
                                                                  final HttpHeaders headers,
                                                                  final HttpStatusCode status,
                                                                  final WebRequest request) {

        log.error("OSEI - Method argument not valid exception -> {}", ex.getMessage(), ex);
        final ApiError apiError = new ApiError();
        apiError.setCode(HttpStatus.BAD_REQUEST.getReasonPhrase());


        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            apiError.addMessagesItem(fieldName + ": " + errorMessage);
        });
        return new ResponseEntity<>(apiError, new HttpHeaders(), status);
    }

    /**
     * Handle invalid format exception.
     *
     * @param exception the exception.
     * @return a {@code ResponseEntity} instance.
     */
    @ExceptionHandler({InvalidFormatException.class})
    public ResponseEntity<Object> handleInputNotReadableException(final Exception exception) {
        log.error("OSEI - Invalid format exception -> {}", exception.getMessage(), exception);
        final ApiError apiError = new ApiError();
        final Throwable cause = exception.getCause() == null ? exception : exception.getCause();
        if (cause instanceof InvalidFormatException) {
            final StringBuilder fieldName = new StringBuilder();
            for (final Reference reference : ((InvalidFormatException) cause).getPath()) {
                if (reference.getFrom() instanceof List) {
                    fieldName.append("[");
                    fieldName.append(reference.getIndex());
                    fieldName.append("].");
                } else {
                    fieldName.append(reference.getFieldName());
                }

            }
            messageSourceAccessor = new MessageSourceAccessor(messageSource);
            String value = messageSourceAccessor.getMessage(ErrorMessage.INVALID_INPUT_ERROR,
                    new Object[]{((InvalidFormatException) cause).getValue()});
            apiError.addMessagesItem(fieldName + ": " + value);
        } else if (cause instanceof DateTimeParseException) {
            String errorValue = ((DateTimeParseException) cause).getParsedString();
            messageSourceAccessor = new MessageSourceAccessor(messageSource);
            String value = messageSourceAccessor.getMessage(ErrorMessage.DATE_INVALID_ERROR,
                    new Object[]{errorValue});
            apiError.addMessagesItem(value);
        }
        apiError.setCode(HttpStatus.BAD_REQUEST.getReasonPhrase());

        return new ResponseEntity<>(apiError, new HttpHeaders(), HttpStatus.BAD_REQUEST);
    }

    /**
     * Provides handling for MethodArgumentNotValidException exceptions.
     *
     * @param exception the MethodArgumentNotValidException.
     * @param request   the current request.
     * @return A response entity with error message and status code.
     */
    @Override
    public ResponseEntity<Object> handleHttpMessageNotReadable(final HttpMessageNotReadableException exception,
                                                               final HttpHeaders headers,
                                                               final HttpStatusCode status,
                                                               final WebRequest request) {
        log.error("OSEI -Failed due to Invalid Request {}", exception.getMessage(), exception);

        final ApiError apiError = new ApiError();
        if (exception.getCause() instanceof InvalidFormatException) {
            return handleInputNotReadableException((Exception) exception.getCause());
        }
        if (exception.getCause() instanceof JsonMappingException) {
            return handleJsonMappingException((JsonMappingException) exception.getCause(), status);
        }
        String message = "";
        if (exception.getMostSpecificCause() != null) {
            message = exception.getMostSpecificCause().getLocalizedMessage();
        } else {
            message = exception.getMessage();
        }

        apiError.addMessagesItem(message);
        apiError.setCode(HttpStatus.BAD_REQUEST.getReasonPhrase());
        return new ResponseEntity<>(apiError, new HttpHeaders(), status);
    }

    /**
     * Handle Json mapping exception.
     *
     * @param e the exception.
     * @return a {@code ResponseEntity} instance.
     */
    @ExceptionHandler(JsonMappingException.class)
    public ResponseEntity<Object> handleJsonMappingException(final JsonMappingException e, final HttpStatusCode status) {
        log.error("OSEI -Json mapping exception -> {}", e.getMessage(), e);

        final ApiError apiError = new ApiError();

        final StringBuilder fieldName = new StringBuilder();
        for (final Reference reference : e.getPath()) {
            if (reference.getFrom() instanceof List) {
                fieldName.append("[");
                fieldName.append(reference.getIndex());
                fieldName.append("].");
            } else if (StringUtils.isNotEmpty(fieldName) && !(fieldName.toString()).endsWith(".")) {
                fieldName.append(".");
                fieldName.append(reference.getFieldName());
            } else {
                fieldName.append(reference.getFieldName());
            }

        }
        messageSourceAccessor = new MessageSourceAccessor(messageSource);
        String value;
        apiError.setCode(HttpStatus.BAD_REQUEST.getReasonPhrase());

        if (e.getCause() instanceof DateTimeParseException) {
            DateTimeParseException dateTimeException = ((DateTimeParseException) e.getCause());
            value = dateTimeException.getParsedString();
            value = messageSourceAccessor.getMessage(ErrorMessage.DATE_INVALID_ERROR, new Object[]{value});
            apiError.addMessagesItem(fieldName + ": " + value);

        } else {
            value = messageSourceAccessor.getMessage(ErrorMessage.INVALID_INPUT_ERROR, new Object[]{""});
            apiError.addMessagesItem(fieldName + ": " + value + " " + e.getCause().getLocalizedMessage());
        }


        return new ResponseEntity<>(apiError, new HttpHeaders(), status);
    }

    /**
     * Handle all exception
     *
     * @param ex      the exception.
     * @param request the current request.
     * @return a {@code ResponseEntity} instance.
     */
    @ExceptionHandler({Exception.class})
    public ResponseEntity<Object> handleAllException(final Exception ex, final WebRequest request) {

        log.error("OSEI - handle all exception -> {}", ex.getMessage(), ex);

        if (StringUtils.equals(MDC.get(Constants.ENDPOINT_NAME), Constants.V1_PROCESS_DOCUMENT)) {
            processDocumentArDbService.updateErrorInProcessAr(MDC.get(Constants.CORRELATION_ID), ex.getMessage());
        }
        final ApiError apiError = new ApiError();

        messageSourceAccessor = new MessageSourceAccessor(messageSource);
        apiError.addMessagesItem(messageSourceAccessor.getMessage(ErrorMessage.INTERNAL_SERVER_ERROR));
        apiError.setCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());

        return new ResponseEntity<>(apiError, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    /**
     * Handle client exception
     *
     * @param clientException the exception
     * @return a {@code ResponseEntity} instance.
     */
    @ExceptionHandler({ClientException.class})
    public ResponseEntity<Object> handleClientException(final ClientException clientException) {
        log.error("OSEI -Client Exception -> {}", clientException.getMessage(), clientException);
        //call DB Service to store error data in DB
        if (StringUtils.equals(clientException.getApiName(), Constants.V1_PROCESS_DOCUMENT)) {
            processDocumentArDbService.updateErrorInProcessAr(clientException.getEDocumentId(), clientException.getMessage());
        }
        final ApiError apiError = new ApiError();

        apiError.setCode(String.valueOf(clientException.getStatusCode()));
        apiError.addMessagesItem(clientException.getMessage());
        return new ResponseEntity<>(apiError, new HttpHeaders(), clientException.getStatusCode());
    }

    @ExceptionHandler(PUFValidationException.class)
    public ResponseEntity<ApiError> pufValidationException(final PUFValidationException e) {
        log.error("OSEI - PUF validation failed exception -> {}", e.getMessages());
        if (StringUtils.equals(MDC.get(Constants.ENDPOINT_NAME), Constants.V1_PROCESS_DOCUMENT)) {
            processDocumentArDbService.updateErrorInProcessAr(MDC.get(Constants.CORRELATION_ID), e.getMessage());
        }
        ApiError apiError = new ApiError();
        apiError.setCode(e.getCode());
        e.getMessages().forEach(apiError::addMessagesItem);
        return ResponseEntity.internalServerError().body(apiError);
    }

    /**
     * Handle application exception
     *
     * @param e the exception.
     * @return a {@code ResponseEntity} instance.
     */
    @ExceptionHandler({ApplicationException.class})
    public ResponseEntity<Object> applicationException(ApplicationException e) {
        log.error("OSEI - application exception -> {}", e.getMessage(), e);

        if (StringUtils.equals(MDC.get(Constants.ENDPOINT_NAME), Constants.V1_PROCESS_DOCUMENT)) {
            processDocumentArDbService.updateErrorInProcessAr(MDC.get(Constants.CORRELATION_ID), e.getMessage());
        }
        final ApiError apiError = new ApiError();
        apiError.setCode(e.getCode());
        apiError.addMessagesItem(e.getMessage());
        return new ResponseEntity<>(apiError, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);

    }

    /**
     * This method is used to handle exceptions related to DB
     *
     * @param dbException
     * @return
     */
    @ExceptionHandler({DBException.class})
    public ResponseEntity<Object> handleDBException(final DBException dbException) { 
        // todo 1 for 400
        log.error("OSEI -DB related Exception -> {}", dbException.getMessage(), dbException);
        final ApiError apiError = new ApiError();
        HttpStatusCode httpStatusCode = HttpStatus.INTERNAL_SERVER_ERROR;
        if (Objects.nonNull(dbException.getHttpStatusCode())
                && dbException.getHttpStatusCode().is4xxClientError()) {

            apiError.setCode("BAD_REQUEST");

            httpStatusCode = dbException.getHttpStatusCode();
        } else {
            if (StringUtils.equals(MDC.get(Constants.ENDPOINT_NAME), Constants.V1_PROCESS_DOCUMENT)) {
                processDocumentArDbService.updateErrorInProcessAr(MDC.get(Constants.CORRELATION_ID), dbException.getMessage());
            }
            apiError.setCode("INTERNAL_SERVER_ERROR");
        }
        messageSourceAccessor = new MessageSourceAccessor(messageSource);
        apiError.addMessagesItem(messageSourceAccessor.getMessage(dbException.getMessage()));

        return new ResponseEntity<>(apiError, new HttpHeaders(), httpStatusCode);
    }
    @ExceptionHandler({UiException.class})
    public ResponseEntity<Object> handleUIException(final UiException uiException){
        // todo 2 for 400
        log.error("OSEI -UI related Exception -> {}", uiException.getMessage(), uiException);
        final ApiError apiError = new ApiError();
        HttpStatusCode httpStatusCode = HttpStatus.INTERNAL_SERVER_ERROR;
        if(Objects.nonNull(uiException.getHttpStatusCode())
                && uiException.getHttpStatusCode().is4xxClientError()){

            apiError.setCode("BAD_REQUEST");

            httpStatusCode=uiException.getHttpStatusCode();
        }else{
            if (StringUtils.equals(MDC.get(Constants.ENDPOINT_NAME), Constants.V1_PROCESS_DOCUMENT)) {
                processDocumentArDbService.updateErrorInProcessAr(MDC.get(Constants.CORRELATION_ID), uiException.getMessage());
            }
            apiError.setCode("INTERNAL_SERVER_ERROR");
        }
        apiError.addMessagesItem(uiException.getMessage());

        return new ResponseEntity<>(apiError, new HttpHeaders(), httpStatusCode);
    }


    /**
     * Handle NotFoundException.
     *
     * @param e the exception.
     * @return a {@code ResponseEntity} instance.
     */
    @ExceptionHandler({NotFoundException.class})
    public ResponseEntity<Object> handleNotFoundException(final NotFoundException e) {
        log.error("OSEI - handle not found exception -> {}", e.getMessage(), e);
        final ApiError apiError = new ApiError();

        apiError.setCode(e.getCode());

        messageSourceAccessor = new MessageSourceAccessor(messageSource);
        apiError.addMessagesItem(messageSourceAccessor.getMessage(ErrorMessage.NOT_FOUND,
                new Object[]{e.getMessage()}));

        ApplicationResponseMapper mapper = Mappers.getMapper(ApplicationResponseMapper.class);

        ApplicationResponse applicationResponse = new ApplicationResponse();
        DocumentResponse documentResponse = mapper.toDocumentResponse(DBStatusCodeConstants.ERROR, apiError);
        mapper.addDocumentResponse(applicationResponse, documentResponse);

        return new ResponseEntity<>(applicationResponse, new HttpHeaders(), HttpStatus.NOT_FOUND);
    }

}

