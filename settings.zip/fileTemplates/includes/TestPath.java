#set($folder = "")
#set($foreach = "")
#set($rootRelativePath = "")
#set($endRootPath = "..")
#foreach ($folder in ${StringUtils.split(${PACKAGE_NAME},".")})
#set($rootRelativePath = "$!rootRelativePath../")
#if ($foreach.hasNext == false)
#set($rootRelativePath = "$!rootRelativePath$endRootPath")
#end
#end
#set($c =${PACKAGE_NAME})
#set( $dac = "/../test/java/" )
#set( $b = $c.replace(".", "/") )
#set( $d = "$rootRelativePath$dac$b" )
$d