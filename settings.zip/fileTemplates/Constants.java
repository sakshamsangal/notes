/*
 * Copyright 2023 Thomson Reuters/ONESOURCE. All rights reserved.
 */
package ${PACKAGE_NAME};

/**
 * This class is used to maintain all constants except error messages
 */
public class ${NAME} {

    public static final String PAYLOAD = "payload";
   
    private ${NAME}() {
    }


}
