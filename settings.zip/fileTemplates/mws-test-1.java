package ${PACKAGE_NAME};

import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.AfterEach;

import java.io.IOException;

class ${NAME}Test {

    private final MockWebServer mockWebServer = new MockWebServer();

    @AfterEach
    void tearDown() throws IOException {
        mockWebServer.shutdown();
    }


}
