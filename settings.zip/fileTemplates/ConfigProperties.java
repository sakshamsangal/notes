/*
 * Copyright 2023 Thomson Reuters/ONESOURCE. All rights reserved.
 */
package ${PACKAGE_NAME};

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;


@Configuration
@ConfigurationProperties(prefix = "einv")
@Getter
@Setter
public class ${NAME} {

    private String tokenURL;

    @Value("${businessResponse.process.rows}")
    private int businessResponseProcessRows;

}
