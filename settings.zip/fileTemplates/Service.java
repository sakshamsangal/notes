package ${PACKAGE_NAME};

import com.thomsonreuters.einv.api.exception.NotFoundException;
import com.thomsonreuters.einv.api.mapper.app_res.ApplicationResponseMapper;
import com.thomsonreuters.einv.api.model.error.ApiError;
import com.thomsonreuters.einv.api.model.process_document.request.*;
import com.thomsonreuters.einv.api.persistence.entity.BusinessResAr;
import com.thomsonreuters.einv.api.persistence.entity.LegalEntityParty;
import com.thomsonreuters.einv.api.persistence.entity.ProcessDocumentAr;
import com.thomsonreuters.einv.api.persistence.repositories.BusinessResArRepository;
import com.thomsonreuters.einv.api.persistence.repositories.PartyEntityRepository;
import com.thomsonreuters.einv.api.persistence.repositories.ProcessDocumentArRepository;
import com.thomsonreuters.einv.api.util.Constants;
import com.thomsonreuters.einv.api.util.DBStatusCodeConstants;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Slf4j
@Service
@RequiredArgsConstructor
public class ${NAME} {


}
