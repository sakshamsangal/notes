/*
 * Copyright 2023 Thomson Reuters/ONESOURCE. All rights reserved.
 */
package ${PACKAGE_NAME};

import lombok.Getter;


/**
 * This is a custom exception handler for application exception
 */
@Getter
public class ${NAME} extends RuntimeException {
    private final String code;
    private final String message;


    public ${NAME}(String code, String message, final Throwable cause) {
        super(message, cause);
        this.code = code;
        this.message = message;

    }


}
