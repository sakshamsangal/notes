package com.google.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RequestParamController {

    @RequestMapping("select-user-request-param")
    public ModelAndView insertUser(@RequestParam(value = "id", required = false, defaultValue = "12") int id, @RequestParam("userName") String userName) {
        ModelAndView modelAndView = new ModelAndView("selectUser");
        System.out.println(id);
        System.out.println(userName);
        return modelAndView;
    }
}
