package com.google.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PrimitiveController {

    @RequestMapping("select-primitive")
    public ModelAndView selectPrimitive() {

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("selectPrimitive");

        modelAndView.addObject("id", 12);
        modelAndView.addObject("name", "sak");
        modelAndView.addObject("salary", "123");

        return modelAndView;
    }
}
