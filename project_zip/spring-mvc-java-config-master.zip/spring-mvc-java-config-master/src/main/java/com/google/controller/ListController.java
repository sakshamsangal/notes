package com.google.controller;


import com.google.model.pojo.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ListController {

    @RequestMapping("select-list")
    public ModelAndView sendList() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("selectList");

        Employee employee1 = new Employee();
        employee1.setId(111);
        employee1.setName("sahitya");
        employee1.setSalary("4565");


        Employee employee2 = new Employee();
        employee2.setId(121);
        employee2.setName("sahitya2");
        employee2.setSalary("45656575");

        List<Employee> employees = new ArrayList<>();
        employees.add(employee1);
        employees.add(employee2);

        modelAndView.addObject("employees", employees);
        return modelAndView;
    }

}
