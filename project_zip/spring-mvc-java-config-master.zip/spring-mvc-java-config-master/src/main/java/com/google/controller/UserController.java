package com.google.controller;

import com.google.model.pojo.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class UserController {

    @RequestMapping("insert-user")
    public String insertUser() {
        return "insertUser";
    }

    @RequestMapping(value = "select-user", method = RequestMethod.POST)
    public String selectUser(@ModelAttribute("user") User user, ModelMap modelMap) {
        System.out.println(user);
        modelMap.addAttribute("user", user);
        return "selectUser";
    }
}
