package com.google.controller;


import com.google.model.pojo.Employee;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ObjectController {

    @RequestMapping("select-object")
    public ModelAndView sendObject() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("selectObject");

        Employee employee = new Employee();
        employee.setId(111);
        employee.setName("sahitya");
        employee.setSalary("4565");

        modelAndView.addObject(employee);

        return modelAndView;
    }

}
