class LinkedList:
    def __init__(self, value):
        self.value = value
        self.next = None


def sumOfLinkedLists(linkedListOne, linkedListTwo):
    res = LinkedList(0)
    carry = 0
    while linkedListOne and linkedListTwo:
        sum = linkedListOne.value + linkedListTwo.value + carry
        if sum < 10:
            res.next = LinkedList(sum)
            carry = 0
        else:
            res.next = LinkedList(sum % 10)
            carry = sum // 10

        linkedListOne = linkedListOne.next
        linkedListTwo = linkedListTwo.next

    while linkedListOne:
        sum = linkedListOne.value + carry
        if sum < 10:
            res.next = LinkedList(sum)
            carry = 0
        else:
            res.next = LinkedList(sum % 10)
            carry = sum // 10

        linkedListOne = linkedListOne.next

    while linkedListTwo:
        sum = linkedListTwo.value + carry
        if sum < 10:
            res.next = LinkedList(sum)
            carry = 0
        else:
            res.next = LinkedList(sum % 10)
            carry = sum // 10

        linkedListTwo = linkedListTwo.next

    if carry != 0:
        res.next = LinkedList(carry)

    return res.next
