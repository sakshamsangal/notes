g = [3, 4, 7, 9]
s = [1, 2, 4]

g.sort()
s.sort()

i = j = 0
l1 = len(g)
l2 = len(s)
while i < l1 and j < l2:
    if g[i] < s[j]:
        i += 1
    j += 1

print(i)
