import re

# pattern = '.*/c(?:/d)?(?:/e)?'
pattern = '.*/c(/|d|e|f){0,3}'
str = 'a/b/c/d/e'
pat = re.compile(pattern)
if re.fullmatch(pat, str):
    print('1')
else:
    print('0')
