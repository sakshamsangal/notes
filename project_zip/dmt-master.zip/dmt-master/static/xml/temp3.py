a = [3, 4, 5, 1, 3, 10]
my_min = my_max = a[0]
max_pro = 0
l = len(a)
for i in range(1, l):
    if a[i] < my_min:
        my_min = a[i]
        my_max = a[i]
    else:
        my_max = a[i]
        diff = my_max - my_min
        if max_pro < diff:
            max_pro = diff

print(max_pro)
