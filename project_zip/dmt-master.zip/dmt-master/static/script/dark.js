document.querySelector("#dark_id").onclick = function (e) {
    e.preventDefault()
    darkmode.toggleDarkMode();
}
