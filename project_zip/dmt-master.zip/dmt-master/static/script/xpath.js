$(document).ready(function () {
    var table = $('#xpath').DataTable({
        // "dom": '<"pull-left"f><"pull-right"l>tip',
        // language: {search: "", searchPlaceholder: "Search..."}
        // "paging": false,
        // "info": false
        scrollX: '100%',
        scrollY: '60vh'

    });
});


