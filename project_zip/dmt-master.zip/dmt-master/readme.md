## This projects simplifies XML mining. It can also generate doc file sing Jijna2 and DocxTemplate.

![alt text](static/readme/prod.png)

![alt text](static/readme/doc.png)