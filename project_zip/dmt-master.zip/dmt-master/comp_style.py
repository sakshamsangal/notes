import re

if re.match(r"lavi", 'hello/sak/lavi/para1/para2'):
    print('Yes')