// install package globally
npm install npkill -g

// delete folder
npx npkill


[](https://medium.com/javascript-in-plain-english/quickly-remove-all-node-modules-folders-from-your-system-to-free-up-the-disk-space-efe9fe99e234)