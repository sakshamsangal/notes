```
Basic MTIzNDU2Nzg5OTpzdHJpbmdBQDE=

Bearer eyJraWQiOiJhZjAwMzUwMy0yYzUwLTQyNjQtYjQyNy1mN2ZlNWMwZmQ1NDMiLCJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJhdWQiOiJiZjA1OWNlOS1mOWY3LTQwYWItYTU3NC1hMmYyN2ViOTY0NGUiLCJpc3MiOiJodHRwczovL0Zvb2RPcmRlcmluZ0FwcC5pbyIsImV4cCI6MTYwNDc2MiwiaWF0IjoxNjA0NzMzfQ.8H6niMVczXQD9g5n3OTL12Rj1KN8lgWwmDd76f8ImtRSsxaGFWj22r9cXhEYWXe29fEiEzbVoKMthOjxJCUDyA


{
  "city": "string",
  "flat_building_name": "string",
  "locality": "string",
  "pincode": "251001",
  "state_uuid": "24615c0e-a238-11e8-9077-720006ceb890"
}

{
  "address_id": "8584c42a-c8a0-4268-9b81-58ee64eefbdd",
  "bill": 200,
  "coupon_id": "2ddf6284-ecd0-11e8-8eb2-f2801f1b9fd1",
  "discount": 0,
  "item_quantities": [
    {
      "item_id": "c860e78a-a29b-11e8-9a3a-720006ceb890",
      "price": 200,
      "quantity": 1
    }
  ],
  "payment_id": "2ddf63b0-ecd0-11e8-8eb2-f2801f1b9fd1",
  "restaurant_id": "9df46816-a294-11e8-9a3a-720006ceb890"
}


```