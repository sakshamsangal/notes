# class
```java
export class Person {
    constructor(
        public email: string,
        public password: string
    ){}
}
