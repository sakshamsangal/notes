```bash
npm install bootstrap --save
angular.json
	"node_modules/bootstrap/dist/css/bootstrap.min.css",
ng build


