npm install --save font-awesome angular-font-awesome
# angular.json
	"node_modules/font-awesome/css/font-awesome.css"

ng build