"node_modules/jquery/dist/jquery.js"
import * as $ from "jquery";