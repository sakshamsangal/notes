# Make firebase project
    https://console.firebase.google.com/
    create new project

# Make hosting folder
    npm install -g firebase-tools
    firebase init hosting.
    paste html pages in public folder.
    firebase deploy.