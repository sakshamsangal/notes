``` html
<table class="table table-dark table-striped table-sm">
  <tr>
    <th>id</th>
    <th>code</th>
    <th>name</th>
    <th>type</th>
    <th>Delete</th>
    <th>Edit</th>
  </tr>
</table>
```
``` html
<div class="table-responsive">
    <table class="table table-dark table-striped table-sm">
      <thead>
        <tr>
          <th>Firstname</th>
          <th>Lastname</th>
          <th>Email</th>
          <th>Lastname</th>
          <th>Email</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>John</td>
          <td>Doe</td>
          <td>mary@example.com</td>
          <td>mary@example.com</td>
          <td>john@example.com</td>
        </tr>
        <tr>
          <td>Mary</td>
          <td>Moe</td>
          <td>mary@example.com</td>
          <td>mary@example.com</td>
          <td>mary@example.com</td>
        </tr>
        <tr>
          <td>July</td>
          <td>Dooley</td>
          <td>july@example.com</td>
          <td>mary@example.com</td>
          <td>mary@example.com</td>
  
        </tr>
      </tbody>
    </table>
  </div> 
```

