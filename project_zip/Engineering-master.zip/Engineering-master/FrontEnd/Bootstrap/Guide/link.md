```
<a href="insertLocationPage" 
    class="btn btn-primary btn-sm float-right">
    Insert  Location
</a>
```