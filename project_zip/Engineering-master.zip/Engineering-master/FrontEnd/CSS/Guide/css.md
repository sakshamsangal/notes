# css

## styles
```css
body {
    background-color: #222;
    color: #aaa;
    font-family: 'JetBrains Mono', serif;
}
```