(function() {
    let x = "Hello!!";
    console.log(x);
})();
