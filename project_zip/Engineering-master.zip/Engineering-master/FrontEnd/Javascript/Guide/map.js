// get squares
let arr = [3, 5, 2, 6, 9]

let squares = arr.map((element) => {
    return Math.pow(element, 2);
})

console.log(squares)