```javascript

str = "12";
var n = +str;
console.log(n + 3);
```
