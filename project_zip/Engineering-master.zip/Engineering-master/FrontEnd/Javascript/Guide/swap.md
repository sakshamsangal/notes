```
var num1 = 1, num2 = 2;
function swap(a, b) {
    num1 = b;
    num2 = a;
}
swap(num1, num2)

```