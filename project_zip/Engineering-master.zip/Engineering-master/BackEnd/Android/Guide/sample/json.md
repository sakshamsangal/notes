# Sample JSON

## main/assets/temp.json
```
{
  "formulas": [
    {
      "formulae": "Linear Motion",
      "url": "qp1"
    },
    {
      "formulae": "Constant Acceleration Motion",
      "url": "qp2"
    }
  ]
}
```