/**
  * TODO: 2.1. Declare 6 private instance variables in this class named as postId,
  * emailId, tag, title, description, timestamp. Out of these 6 variables, postId
  * will be of type int and timestamp will be of type LocalDateTime
  * (import java.time.LocalDateTime). Other four variables will be of type String.
  *
  * TODO: 2.2. Provide getters and setters for each of the instance variables.
  *
  * Note: Uncomment the toString() method given below, instead of writing a new one.
  */



/**
  * This method re-generates hashed Password from raw-password and salt.
  * This will be used during authentication.
  *
  * @param password char array.
  * @param salt     byte array.
  * @return byte array of hashed password.
  */

