```text
netstat -ano | findstr :8080
taskkill /PID <PID> /F
```