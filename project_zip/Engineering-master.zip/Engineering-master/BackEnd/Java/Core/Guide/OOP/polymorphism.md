    Polymorphism:
```
    Polymorphism is that in which we can perform a task in multiple forms or ways. It is applied to the functions or methods. Polymorphism allows the object to decide which form of the function to implement at compile-time as well as run-time.

    Runtime polymorphism or Dynamic Method Dispatch is a process in which a call to an overridden method is resolved at runtime rather than compile-time.

In this process, an overridden method is called through the reference variable of a superclass. The determination of the method to be called is based on the object being referred to by the reference variable.

eg

 


 

Out here will be "running safely with 60km."

Below are some of the rules of runtime polymorphism:

Methods of child and parent class must have the same name.
Methods of child and parent class must have the same parameter.
IS-A relationship is mandatory (inheritance).
Below are some of the limitations of runtime polymorphism

One cannot override private methods of a parent class.
One cannot override Final methods.
One cannot override static methods.
```