```
The object class defines all base state and behavior of objects. Object class is the parent class of all the classes in java by default. In Java, we are viewing everything in the form of an object. So, in order to have a basic common behavior and state of every object which we create for classes that should be defined somewhere. The Object class serves this purpose. 

Object class methods are available to all Java classes. Hence Object class acts as a root of inheritance hierarchy in any Java Program.
```
