# What is spring?
Used to seperate POJO creation from project.

# Merits
Develop can focus on business logic instead of object creation


# Request flow
controller / service / dao / database

# How spring is able to create object seperately?
Spring use `<bean>` or @Component to do this

She can fill the object in two ways:
  + setter method
  + constructor

***
[Back](./index.md)
