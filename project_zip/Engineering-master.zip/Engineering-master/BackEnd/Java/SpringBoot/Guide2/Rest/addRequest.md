```
add request api

@PostMapping("/add-request")
public void addRequest(@ResponseBody Object object) {
        String url = "https://egw-integrate-uat.canarahsbclife.com/service-desk-add-request-api/v1.0.0/requests";

        // set headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        headers.add("Authorization", "Bearer 623c0324-4395-3769-a8b9-49d3c8be91e9");

        // make form urlencoded body
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("input_data", "{\"request\":{\"subject\":\"Need an External Monitor3\",\"resolution\":{\"add_to_linked_requests\":false,\"content\":\"The following is the resolution to the above request\"},\"mode\":{\"name\":\"E-Mail\",\"id\":\"1\"},\"group\":{\"name\":\"Telecom\",\"id\":\"7202\"},\"requester\":{\"name\":\"Rahul Raj\",\"id\":\"155711\"},\"impact\":{\"name\":\"Affects User\",\"id\":\"4\"},\"subcategory\":{\"name\":\"Freeware\",\"id\":\"31001\"},\"request_type\":{\"name\":\"Incident\",\"id\":\"1\"},\"description\":\"Provide me an External Monitor\",\"urgency\":{\"name\":\"Low\",\"id\":\"4\"},\"technician\":{\"name\":\"Anil Sharma\",\"id\":\"127313\"},\"category\":{\"name\":\"Software1\",\"id\":\"5740\"}}}");

        // make a request entity by combining body and headers
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(map, headers);

        // hit the endpoint
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);


        if (response.getStatusCodeValue() == 200) {
            String body = response.getBody();
            // filter the body data according to our needs (Rajat needs to tell me the imp data)
            // save the data to db (working in local)
        } else {
            // throw exception
        }

}

Output:
This is the output of add request (api consumed)

{"request":{"ola_due_by_time":null,"subject":"Need an External Monitor3","resolution":{"submitted_on":{"display_value":"Feb 19, 2021 06:43 PM","value":"1613740405047"},"submitted_by":{"email_id":"","name":"administrator","is_vipuser":false,"id":"3","department":null},"resolution_attachments":[],"content":"The following is the resolution to the above request"},"linked_to_request":null,"mode":{"name":"E-Mail","id":"1"},"is_read":false,"lifecycle":null,"reason_for_cancel":null,"assets":[],"is_trashed":false,"id":"818745","assigned_time":{"display_value":"Feb 19, 2021 06:43 PM","value":"1613740405078"},"group":{"site":null,"name":"Telecom","id":"306"},"requester":{"email_id":"rahul.jain@canarahsbclife.in","name":"Rahul Jain","is_vipuser":false,"id":"155711","department":{"site":null,"name":"Risk","id":21398}},"cancel_requested_by":null,"email_to":[],"created_time":{"display_value":"Feb 19, 2021 06:43 PM","value":"1613740405047"},"item":null,"has_resolution_attachments":false,"approval_status":null,"impact":{"name":"Affects User","id":"4"},"sla":null,"priority":null,"created_by":{"email_id":"","name":"administrator","is_vipuser":false,"id":"3","department":null},"scheduled_end_time":null,"tags":[],"first_response_due_by_time":null,"last_updated_time":null,"has_notes":false,"udf_fields":{"udf_pick_44758":"L1","udf_sline_44757":null,"udf_pick_44754":null,"udf_sline_46816":null,"udf_pick_44756":null,"udf_mline_44755":null,"udf_mline_44759":null,"udf_date_44762":null,"udf_mline_46818":null,"udf_mline_46819":null,"udf_pick_45015":null,"udf_sline_45915":null,"udf_sline_45615":null,"udf_pick_47419":null,"udf_pick_47715":"FALSE","udf_pick_47416":null,"udf_sline_45316":null,"udf_sline_46820":null,"udf_sline_47118":null,"udf_sline_44760":null,"udf_sline_47115":null,"udf_mline_47117":null,"udf_mline_47415":null,"udf_long_46817":null,"udf_mline_47116":null,"udf_mline_47418":null,"udf_pick_44751":null,"udf_pick_44752":null},"impact_details":null,"subcategory":{"name":"Freeware","id":"31001"},"email_cc":[],"status":{"color":"#00ff00","name":"Open","id":"1"},"scheduled_start_time":null,"template":{"is_service_template":false,"name":"Default Request","id":"601"},"email_ids_to_notify":[],"request_type":{"name":"Incident","id":"1"},"cancel_requested_time":null,"notification_status":null,"description":"Provide me an External Monitor","has_dependency":false,"has_conversation":false,"callback_url":null,"chat_type":0,"is_service_request":false,"urgency":{"name":"Low","id":"4"},"is_shared":false,"cancel_requested":false,"has_request_initiated_change":false,"request_template_task_ids":[],"department":{"site":null,"name":"Risk","id":"21398"},"is_reopened":false,"has_draft":false,"has_attachments":false,"has_linked_requests":false,"is_overdue":false,"technician":{"email_id":"networksupport@canarahsbclife.in","name":"Anil Sharma","is_vipuser":false,"id":"127313","department":{"site":null,"name":"Information Technology","id":2354}},"has_request_caused_by_change":false,"has_problem":false,"due_by_time":null,"has_project":false,"site":null,"is_first_response_overdue":false,"cancel_requested_is_pending":false,"recommend_template":null,"unreplied_count":null,"category":{"name":"Software1","id":"5740"}},"response_status":{"status_code":2000,"status":"success"}}

```