# Database caching

## pom 
+ cache
+ hazelcast
+ hazelcast-spring

## Business logic 
``` java

```
## in main class

## in Product class 
`Product implements Serializable`

## in rest controller
``` java

Product getProduct()

deleteProduct() 
```