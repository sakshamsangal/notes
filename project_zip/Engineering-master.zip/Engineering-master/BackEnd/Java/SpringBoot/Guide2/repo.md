```java
public interface LocationRepository extends JpaRepository<Location, Integer> {

}

```