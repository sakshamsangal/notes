```text
restTemplate object 
prod = getForObject("/atricles", Product.class)
assertnotnull prod 
assert equesl Iphone prod name 
```