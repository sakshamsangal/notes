```
Logger LOGGER = LoggerFactory.getLogger(ReservationController.class);

LOGGER.info("completeReservation()  " + request);
```