## ModalAndView:
```
ModalAndView fun() {
    modalAndView.setView("login");
    return modalAndView;
}
```
## ModalMap:
```
String fun(ModalMap map) {
    map.addAttribute("gender", "male");
    return "login"
}

Optional<Flight> = Object is not confirmed to be made.

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class })
controller
modal
    dto
    dao
    service
    util
view

```
## lesssecureapps
https://myaccount.google.com/lesssecureapps