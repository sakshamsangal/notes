# Report page
```jsp
<img src="pieChart.jpeg"/>
```