# project 
download the project java 8 war and no dependency
make root = error and banner = off
test the code 
create main/webapp/WEB-INF/insertLocationView.jsp

## get insert view 
insert view = backend

## insert/update data 
object = front end 
insertedObject = entityService(object)
send email 
return view + savedObject

entityService(object) = entityRepository(object)
entityRepository = spring boot


# show all data 
list of objects = entityService
return view + list of objects

# update view 
id = front end by url 
object = entityService(id)
return view + object 

# report 
list of object = entityRepository
specify chart type
return view 

# delete 
id = front end 
object = id
entityService(object)

# insert/update view 
bootstrap starter 
grid starter
form starter 
show object = back end
fileds according to entity 

# show view 
bootstrap starter
table starter
list of objects = back end 

