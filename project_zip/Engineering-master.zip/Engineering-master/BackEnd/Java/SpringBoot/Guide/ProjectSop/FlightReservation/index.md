```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Flight Reservation Application</title>
</head>
<body>

<h2>Welcome to the Flight Reservation Application:</h2>
New Users click here to register - <a href="displayRegistrationPage">Register</a><br/>
Existing Users Click her to login-<a href="displayLoginPage">Login</a>
</body>
</html>
```