``` java
spring.datasource.url=jdbc:mysql://localhost:3306/projectdb
spring.datasource.username=root
spring.datasource.password=root

spring.jpa.show-sql=true

spring.mvc.view.prefix=/WEB-INF/views/
spring.mvc.view.suffix=.jsp

#server.context-path=/locationweb


spring.mail.host=smtp.gmail.com
spring.mail.port=587
spring.mail.username=sakshamsangal111
spring.mail.password=pYtHoN_1@6!9
spring.mail.properties.mail.smtp.starttls.enable=true
spring.mail.properties.mail.smtp.starttls.required=true
spring.mail.properties.mail.smtp.auth=true
```