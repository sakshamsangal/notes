```
spring.datasource.url=jdbc:mysql://localhost:3306/reservation
spring.datasource.username=root
spring.datasource.password=root

spring.jpa.show-sql=true

spring.mvc.view.prefix=/WEB-INF/view/
spring.mvc.view.suffix=.jsp

spring.mail.host=smtp.gmail.com
spring.mail.port=587
spring.mail.username=sakshamsangal99
spring.mail.password=pYtHoN_1@6!9
spring.mail.properties.mail.smtp.starttls.enable=true
spring.mail.properties.mail.smtp.starttls.required=true
spring.mail.properties.mail.smtp.auth=true

logging.level.root=INFO
logging.file.path=D:/Temporary
com.flightreservation.itinerary.dirpath=D:/Temporary
com.flightreservation.itinerary.email.subject=Itinerary for your Flight
com.flightreservation.itinerary.email.body=Please find your Itinerary attached.
```