```
src
    main 
        java
        resources
        webapp
pom


java
    com.mylocation
        controller
        entity
        repo
        service
        utility

        
resources/static/css/styles.css


webapps
    WEB-INF
        views
            .jsp
```