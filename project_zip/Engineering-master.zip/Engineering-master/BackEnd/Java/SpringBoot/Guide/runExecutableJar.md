```
open cmd

jps
// 34336 my-location-0.0.1-SNAPSHOT.jar
// 33892 Jps

taskkill -f /PID 34336
// SUCCESS: The process with PID 34336 has been terminated.
```