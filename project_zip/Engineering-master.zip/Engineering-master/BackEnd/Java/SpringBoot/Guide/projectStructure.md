# Design pattern
```
main
    java
        com.mylocation
            controller
                LocationController.java
                LocationRestController.java
            modal
                pojo
                service
                rep
                util 
            main file
    resources
        static 
            css 
                styles.css
            templates
        application.properties
    webapp
        WEB-INF 
            view 
                insertLocation.jsp
                displayLocation.jsp
                updateLocation.jsp
                report.jsp
```