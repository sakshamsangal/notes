ftp://192.168.43.64:2221/

c:\windows\system32\drivers\etc\hosts