```
create view bookview as select ...

3 algo
1. merge
2. temptable
3. undefined (default)

with check option // for avoid select issue
```