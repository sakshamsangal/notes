CREATE DATABASE temp;

CREATE TABLE `sms`.`table1` (
  `c1` INT NOT NULL,
  `c2` BLOB NULL,
  PRIMARY KEY (`c1`));


