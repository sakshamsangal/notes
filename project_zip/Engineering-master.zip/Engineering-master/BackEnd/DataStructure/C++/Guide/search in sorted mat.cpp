// 1. element = take last top vertical space
// 2. element == item return element index
// 3. element < item
//    1. move downward
//    2. goto step 2
// 4. item < element
//    1. move left
//    2. goto step 2