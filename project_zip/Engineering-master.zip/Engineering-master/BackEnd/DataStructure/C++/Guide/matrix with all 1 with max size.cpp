// 1. take 1 row
// 2. element == 0 move right
// 3. element == 1
//    1. size = 1
//    2. if top and left all 1
//         size ++
// 4. repeat step 2, 3 for very row

