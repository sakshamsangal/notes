// 1. binary tree 
// 2. left = 2parent + 1
// 3. right = 2parent + 2
// 4. parent = (child - 1) / 2
