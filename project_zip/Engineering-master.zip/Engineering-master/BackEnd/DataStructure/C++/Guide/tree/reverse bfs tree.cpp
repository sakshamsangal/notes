// 1. make queue and stack
// 2. enqueue parent
// 3. dequeue
// 4. push dequeued
// 5. enqueue children first right then left
// 6. goto 3
// 7. do this until queue is not empty