// if both or none child then do nothing
// if 1 child only then count ++
// apply bfs