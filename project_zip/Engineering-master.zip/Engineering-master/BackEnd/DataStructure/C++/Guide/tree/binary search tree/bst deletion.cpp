// if leaf then delete as it is
// if single child then move single child to that node
// if binary child then move inorder successor to that node
