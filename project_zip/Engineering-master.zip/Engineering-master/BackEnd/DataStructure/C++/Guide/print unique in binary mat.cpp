// make bst
// if item == tree element then do nothing
// else insert to bst
