// infix to postfix
// if variable then print
// if '(' then push 
// if ')' then pop to '('
// if lower or equal precedence then pop to '(' or higher precedence
// if higher precedence then push 