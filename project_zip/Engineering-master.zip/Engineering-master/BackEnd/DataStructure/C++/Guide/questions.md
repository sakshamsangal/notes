void insertNode(int arr[], int& n, int Key)  
    n = n + 1;
insertNode(arr, n, key)