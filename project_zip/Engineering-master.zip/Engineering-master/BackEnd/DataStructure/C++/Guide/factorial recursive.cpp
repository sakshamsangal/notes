// fun3(1)
//     return 1
// fun2(2)
//     return 2 * fun3(1)
// fun1 3
//     retrun 3 * fun2(2) 

// fact(n)
//     if n == 1 return 1
//     return n * fact(n - 1)
    
