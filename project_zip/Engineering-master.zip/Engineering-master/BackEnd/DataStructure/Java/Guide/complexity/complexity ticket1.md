Let n = id.length
let n = 6

Inner loop is getting executed in below fashion:
5, 4, 3, 2, 1
This is sum of n - 1 natural number

sum of n natural number is given by 
sum = n * (n + 1) / 2

Replacing n by n - 1, we get,
sum = n - 1 * (n) / 2

Total complexity = outer loop * inner loop 
Total complexity = n * n - 1 * (n) / 2 + some constant work 


Hi Nikita, Thanks for reaching out to us.



Please refer to below link of the correct solution for the validation of your approach.




Thanks & Regards,
upGrad Tech Support
Happy Learning!
