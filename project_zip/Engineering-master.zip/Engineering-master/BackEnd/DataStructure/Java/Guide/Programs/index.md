```
Initially, the count of every element of id[] in count[] is 0.
Once we encounter any element we increase it count by 1
count[] will store frequency of every element.
id[] is the array element frequency we want to calculate.

count[0] = 0 // frequency of 0 element // 0 is appearing 0 times in id[]
count[1] = 0 // frequency of 1 element // 1 is appearing 0 times in id[]
count[2] = 2 // frequency of 2 element // 2 is appearing 2 times in id[]
count[3] = 1 // frequency of 3 element // 3 is appearing 1 times in id[]
count[4] = 1 // frequency of 4 element // 4 is appearing 1 times in id[]
count[5] = 2 // frequency of 5 element // 5 is appearing 2 times in id[]
count[6] = 1 // frequency of 6 element // 6 is appearing 1 times in id[]
```