```
Algorithm: 
if the right most digit is not divisible by 2 then return false
traverse over the string 
    get the numeric value of digit at the ith place
    get the quotient
    get the remainder


For reference:

https://www.geeksforgeeks.org/given-huge-number-check-power-two/

```


```

```