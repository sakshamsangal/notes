```
Initialise empty map
Traverse through the arr
first1 = first element of arr 
second1 = second element of arr

data = fetching value of key(second1) from the map

if(data is not null and data is equal to first1) {
    print second + " " + first1
    flag = true 
} else {
    add key = first1, value = second1 to map
}

if(flag is false) {
    print "No Symmetric pair"
}



```