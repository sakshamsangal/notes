```
BF/LO
DF - preorder PLR
DF - inorder LPR
DF - postorder LRP



```