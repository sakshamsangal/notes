Flag is used to come out of loop when condition gets satisfied.
Flags are used to improve performance of code.
The main use of flag is to terminate loop.

e.g. program to find the prime number.

